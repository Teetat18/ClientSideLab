function App() {
  return (
    <div>
      <header>
        <img src="" alt="Stylized atom" />
        <h1></h1>
        <p></p>
      </header>
      <main>
        <h2></h2>
      </main>
    </div>
  );
}

export default App;
